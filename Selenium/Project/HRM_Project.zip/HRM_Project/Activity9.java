```java
package com.orangehrm.tests;

import com.orangehrm.base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.List;

public class EmergencyContactTest extends BaseTest {

    @Test
    public void retrieveEmergencyContacts() {

        login();

        driver.findElement(
                By.xpath("//a[contains(text(),'My Info')]")
        ).click();

        driver.findElement(
                By.xpath("//*[contains(text(),'Emergency Contacts')]")
        ).click();

        List<WebElement> rows =
                driver.findElements(
                        By.xpath("//table//tbody/tr")
                );

        System.out.println(
                "Number of emergency contacts: "
                        + rows.size()
        );

        for (WebElement row : rows) {

            List<WebElement> columns =
                    row.findElements(By.tagName("td"));

            StringBuilder contact =
                    new StringBuilder();

            for (WebElement column : columns) {

                contact.append(
                        column.getText()
                ).append(" | ");
            }

            System.out.println(
                    contact
            );
        }
    }
}
```
