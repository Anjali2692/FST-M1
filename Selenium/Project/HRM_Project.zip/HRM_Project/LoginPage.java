```java
package com.orangehrm.pages;

import com.orangehrm.utils.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    private WebDriver driver;

    private By username =
            By.name("txtUserName");

    private By password =
            By.name("txtPassword");

    private By loginButton =
            By.name("Submit");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void login() {

        driver.findElement(username)
                .sendKeys(ConfigReader.get("username"));

        driver.findElement(password)
                .sendKeys(ConfigReader.get("password"));

        driver.findElement(loginButton)
                .click();
    }
}
```
