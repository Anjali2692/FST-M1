```java
package com.orangehrm.tests;

import com.orangehrm.base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DirectoryTest extends BaseTest {

    @Test
    public void verifyDirectoryMenu() {

        login();

        WebElement directory =
                driver.findElement(
                        By.xpath("//a[contains(text(),'Directory')]")
                );

        Assert.assertTrue(
                directory.isDisplayed(),
                "Directory is not visible"
        );

        Assert.assertTrue(
                directory.isEnabled(),
                "Directory is not clickable"
        );

        directory.click();

        WebElement heading =
                driver.findElement(
                        By.xpath("//*[contains(text(),'Search Directory')]")
                );

        Assert.assertEquals(
                heading.getText(),
                "Search Directory"
        );
    }
}
```
