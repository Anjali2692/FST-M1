package com.alchemy.crm.tests;

import com.alchemy.crm.base.BaseTest;
import com.alchemy.crm.pages.AccountsPage;
import com.alchemy.crm.pages.HomePage;
import com.alchemy.crm.pages.LeadsPage;
import com.alchemy.crm.pages.LoginPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CRMTests extends BaseTest {

    @BeforeMethod
    public void launchBrowser() {
        setUp();
    }

    @AfterMethod
    public void closeBrowser() {
        tearDown();
    }

    // ---------------------------------------------------------
    // Activity 1
    // Verify website title
    // ---------------------------------------------------------

    @Test(priority = 1)
    public void verifyWebsiteTitle() {

        String actualTitle = driver.getTitle();

        System.out.println("Website Title: " + actualTitle);

        Assert.assertEquals(
                actualTitle,
                "SuiteCRM",
                "Website title does not match."
        );
    }


    // ---------------------------------------------------------
    // Activity 2
    // Get URL of header image
    // ---------------------------------------------------------

    @Test(priority = 2)
    public void getHeaderImageURL() {

        WebElement headerImage =
                driver.findElement(
                        By.xpath("//img[contains(@src,'logo') or contains(@class,'logo')]")
                );

        String imageURL =
                headerImage.getAttribute("src");

        System.out.println(
                "Header Image URL: " + imageURL
        );

        Assert.assertNotNull(imageURL);
    }


    // ---------------------------------------------------------
    // Activity 3
    // Get copyright text
    // ---------------------------------------------------------

    @Test(priority = 3)
    public void getCopyrightText() {

        WebElement copyright =
                driver.findElement(
                        By.xpath(
                                "//*[contains(text(),'Copyright') or contains(text(),'©')]"
                        )
                );

        String copyrightText =
                copyright.getText();

        System.out.println(
                "Copyright Text: " + copyrightText
        );

        Assert.assertFalse(
                copyrightText.isEmpty()
        );
    }


    // ---------------------------------------------------------
    // Activity 4
    // Login
    // ---------------------------------------------------------

    @Test(priority = 4)
    public void loginToCRM() {

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login();

        HomePage homePage =
                new HomePage(driver);

        Assert.assertTrue(
                homePage.isHomePageDisplayed(),
                "Home page was not displayed after login."
        );

        System.out.println(
                "Login successful."
        );
    }


    // ---------------------------------------------------------
    // Activity 5
    // Get navigation menu color
    // ---------------------------------------------------------

    @Test(priority = 5)
    public void getNavigationMenuColor() {

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login();

        HomePage homePage =
                new HomePage(driver);

        String color =
                homePage.getActivitiesMenuColor();

        System.out.println(
                "Navigation Menu Color: " + color
        );

        Assert.assertNotNull(color);
    }


    // ---------------------------------------------------------
    // Activity 6
    // Verify Activities menu
    // ---------------------------------------------------------

    @Test(priority = 6)
    public void verifyActivitiesMenu() {

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login();

        HomePage homePage =
                new HomePage(driver);

        Assert.assertTrue(
                homePage.isActivitiesClickable(),
                "Activities menu is not clickable."
        );

        System.out.println(
                "Activities menu exists and is clickable."
        );
    }


    // ---------------------------------------------------------
    // Activity 7
    // Read additional information popup
    // ---------------------------------------------------------

    @Test(priority = 7)
    public void readLeadAdditionalInformation() {

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login();

        LeadsPage leadsPage =
                new LeadsPage(driver);

        leadsPage.navigateToLeads();

        leadsPage.printLeadPhoneNumber();
    }


    // ---------------------------------------------------------
    // Activity 8
    // Traverse Accounts table
    // ---------------------------------------------------------

    @Test(priority = 8)
    public void traverseAccountsTable() {

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login();

        AccountsPage accountsPage =
                new AccountsPage(driver);

        accountsPage.navigateToAccounts();

        accountsPage.printFirstFiveOddRows();
    }


    // ---------------------------------------------------------
    // Activity 9
    // Traverse Leads table
    // ---------------------------------------------------------

    @Test(priority = 9)
    public void traverseLeadsTable() {

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login();

        LeadsPage leadsPage =
                new LeadsPage(driver);

        leadsPage.navigateToLeads();

        leadsPage.printFirstTenNamesAndUsers();
    }
}