package com.alchemy.crm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HomePage {

    private WebDriver driver;

    private WebDriverWait wait;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    private By activitiesMenu =
            By.xpath("//a[contains(normalize-space(),'Activities')]");

    public boolean isHomePageDisplayed() {

        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(activitiesMenu)
        ).isDisplayed();
    }

    public String getActivitiesMenuColor() {

        return driver.findElement(activitiesMenu)
                .getCssValue("color");
    }

    public boolean isActivitiesClickable() {

        return driver.findElement(activitiesMenu).isEnabled();
    }
}