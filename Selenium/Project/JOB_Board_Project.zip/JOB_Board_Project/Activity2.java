@Test
public void verifyWebsiteHeading() {

    HomePage homePage = new HomePage(driver);

    String actualHeading = homePage.getMainHeading();

    System.out.println("Heading: " + actualHeading);

    Assert.assertEquals(
            actualHeading,
            "Welcome to Alchemy Jobs"
    );
}