@Test
public void getHeaderImageUrl() {

    HomePage homePage = new HomePage(driver);

    String imageUrl = homePage.getHeaderImageUrl();

    System.out.println("Header Image URL: " + imageUrl);

    Assert.assertNotNull(imageUrl);
    Assert.assertFalse(imageUrl.isEmpty());
}