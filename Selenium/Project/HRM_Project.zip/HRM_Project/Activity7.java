```java
package com.orangehrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class QualificationPage {

    private WebDriver driver;

    private By myInfo =
            By.xpath("//a[contains(text(),'My Info')]");

    private By qualification =
            By.xpath("//*[contains(text(),'Qualifications')]");

    private By addButton =
            By.xpath("//button[contains(text(),'Add')]");

    private By company =
            By.xpath("//input[contains(@placeholder,'Company')]");

    private By jobTitle =
            By.xpath("//input[contains(@placeholder,'Job Title')]");

    private By saveButton =
            By.xpath("//button[contains(text(),'Save')]");

    public QualificationPage(WebDriver driver) {
        this.driver = driver;
    }

    public void addWorkExperience() {

        driver.findElement(myInfo).click();

        driver.findElement(qualification).click();

        driver.findElement(addButton).click();

        driver.findElement(company)
                .sendKeys("IBM");

        driver.findElement(jobTitle)
                .sendKeys("QA Automation Engineer");

        driver.findElement(saveButton).click();
    }
}
```
