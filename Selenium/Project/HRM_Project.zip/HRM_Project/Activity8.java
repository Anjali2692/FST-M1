```java
package com.orangehrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LeavePage {

    private WebDriver driver;

    private By applyLeave =
            By.xpath("//*[contains(text(),'Apply Leave')]");

    private By leaveType =
            By.xpath("//select[contains(@name,'leave')]");

    private By fromDate =
            By.xpath("//input[contains(@placeholder,'From')]");

    private By toDate =
            By.xpath("//input[contains(@placeholder,'To')]");

    private By applyButton =
            By.xpath("//button[contains(text(),'Apply')]");

    public LeavePage(WebDriver driver) {
        this.driver = driver;
    }

    public void applyLeave() {

        driver.findElement(applyLeave).click();

        // Select leave type according to actual DOM

        driver.findElement(fromDate)
                .sendKeys("2026-08-17");

        driver.findElement(toDate)
                .sendKeys("2026-08-18");

        driver.findElement(applyButton).click();
    }
}
```
