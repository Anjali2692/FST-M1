```java
package com.alchemy.lms.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class CoursePage {

    private WebDriver driver;

    private By courseTitle =
            By.cssSelector(
                    "h1.entry-title, h1"
            );

    private By lessons =
            By.cssSelector(
                    ".lesson, .ld-item-list-item"
            );

    private By markComplete =
            By.xpath(
                    "//*[contains(normalize-space(),'Mark Complete')]"
            );

    public CoursePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getCourseTitle() {

        return driver.findElement(courseTitle)
                .getText()
                .trim();
    }

    public void openFirstLesson() {

        List<WebElement> lessonList =
                driver.findElements(lessons);

        if (lessonList.isEmpty()) {

            throw new RuntimeException(
                    "No lessons found in course"
            );
        }

        lessonList.get(0).click();
    }

    public boolean isMarkCompleteAvailable() {

        return !driver.findElements(markComplete)
                .isEmpty();
    }

    public void markComplete() {

        if (isMarkCompleteAvailable()) {

            driver.findElement(markComplete)
                    .click();
        }
    }
}
```
