```java
package com.alchemy.lms.pages;

import com.alchemy.lms.utils.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    private WebDriver driver;

    private By username =
            By.id("user_login");

    private By password =
            By.id("user_pass");

    private By loginButton =
            By.id("wp-submit");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void login() {

        driver.findElement(username)
                .sendKeys(
                        ConfigReader.get("username")
                );

        driver.findElement(password)
                .sendKeys(
                        ConfigReader.get("password")
                );

        driver.findElement(loginButton)
                .click();
    }

    public boolean isLoggedIn() {

        /*
         * Depending on the LMS version,
         * My Account / Logout may be visible.
         */

        return driver.getPageSource()
                .toLowerCase()
                .contains("logout");
    }
}
