package com.alchemy.crm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class AccountsPage {

    private WebDriver driver;

    private WebDriverWait wait;

    public AccountsPage(WebDriver driver) {

        this.driver = driver;

        this.wait =
                new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    private By salesMenu =
            By.xpath("//a[contains(normalize-space(),'Sales')]");

    private By accountsMenu =
            By.xpath("//a[contains(normalize-space(),'Accounts')]");

    private By accountTable =
            By.xpath("//table[contains(@class,'list') or contains(@class,'list-view')]");

    public void navigateToAccounts() {

        wait.until(
                ExpectedConditions.elementToBeClickable(salesMenu)
        ).click();

        wait.until(
                ExpectedConditions.elementToBeClickable(accountsMenu)
        ).click();
    }

    public void printFirstFiveOddRows() {

        WebElement table =
                wait.until(
                        ExpectedConditions.visibilityOfElementLocated(accountTable)
                );

        List<WebElement> rows =
                table.findElements(By.xpath(".//tbody/tr"));

        int printed = 0;

        /*
         * Odd-numbered rows:
         * 1, 3, 5, 7, 9
         */

        for (int i = 0; i < rows.size(); i += 2) {

            WebElement row = rows.get(i);

            List<WebElement> cells =
                    row.findElements(By.xpath("./td"));

            if (!cells.isEmpty()) {

                System.out.println(
                        "Account Row " + (i + 1) +
                        ": " + cells.get(1).getText()
                );

                printed++;
            }

            if (printed == 5) {
                break;
            }
        }
    }
}