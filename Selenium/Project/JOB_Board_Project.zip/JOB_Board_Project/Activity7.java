package com.alchemy.jobs.tests;

import com.alchemy.jobs.base.BaseTest;
import com.alchemy.jobs.pages.HomePage;
import com.alchemy.jobs.pages.PostJobPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PostJobTests extends BaseTest {

    @Test
    public void createNewJobListing() {

        HomePage homePage = new HomePage(driver);

        PostJobPage postJobPage =
                homePage.clickPostJob();

        postJobPage.enterJobDetails(
                "Senior Automation Test Engineer",
                "Hyderabad",
                "Looking for an experienced Selenium Java automation engineer.",
                "Alchemy Test Company",
                "https://example.com",
                "hr@example.com"
        );

        postJobPage.clickPreview();

        postJobPage.submitListing();

        Assert.assertTrue(
                driver.getPageSource()
                        .contains("Senior Automation Test Engineer")
        );
    }
}