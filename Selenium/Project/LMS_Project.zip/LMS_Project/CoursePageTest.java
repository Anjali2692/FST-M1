```java
package com.alchemy.lms.tests;

import com.alchemy.lms.base.BaseTest;
import com.alchemy.lms.pages.CoursePage;
import com.alchemy.lms.pages.CoursesPage;
import com.alchemy.lms.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LessonTest extends BaseTest {

    @Test
    public void completeLesson() {

        HomePage homePage =
                new HomePage(driver);

        homePage.clickAllCourses();

        CoursesPage coursesPage =
                new CoursesPage(driver);

        coursesPage.openFirstCourse();

        CoursePage coursePage =
                new CoursePage(driver);

        String courseTitle =
                coursePage.getCourseTitle();

        System.out.println(
                "Course Title: " + courseTitle
        );

        Assert.assertFalse(
                courseTitle.isEmpty(),
                "Course title is empty"
        );

        coursePage.openFirstLesson();

        String lessonPageTitle =
                driver.getTitle();

        System.out.println(
                "Lesson Page Title: "
                        + lessonPageTitle
        );

        if (coursePage.isMarkCompleteAvailable()) {

            coursePage.markComplete();

            System.out.println(
                    "Lesson marked as complete."
            );

        } else {

            System.out.println(
                    "Mark Complete button is not available."
            );
        }
    }
}
