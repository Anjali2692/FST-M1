```java
package com.alchemy.lms.tests;

import com.alchemy.lms.base.BaseTest;
import com.alchemy.lms.pages.CoursesPage;
import com.alchemy.lms.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CoursesTest extends BaseTest {

    @Test
    public void countCourses() {

        HomePage homePage =
                new HomePage(driver);

        homePage.clickAllCourses();

        CoursesPage coursesPage =
                new CoursesPage(driver);

        int courseCount =
                coursesPage.getCourseCount();

        System.out.println(
                "Number of courses: " + courseCount
        );

        Assert.assertTrue(
                courseCount > 0,
                "No courses found"
        );
    }
}
```
