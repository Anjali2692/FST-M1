package com.alchemy.jobs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class JobsPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public JobsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    private By searchBox =
            By.cssSelector("input[name='search_keywords']");

    private By searchButton =
            By.cssSelector("input[type='submit']");

    private By jobListings =
            By.cssSelector(".job_listings li.job_listing");

    private By firstJob =
            By.cssSelector(".job_listings li.job_listing a");

    public String getPageTitle() {
        return driver.getTitle();
    }

    public void searchJob(String jobName) {

        WebElement search =
                wait.until(ExpectedConditions.visibilityOfElementLocated(searchBox));

        search.clear();
        search.sendKeys(jobName);

        driver.findElement(searchButton).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(jobListings));
    }

    public int getJobCount() {

        List<WebElement> jobs =
                driver.findElements(jobListings);

        return jobs.size();
    }

    public JobDetailsPage openFirstJob() {

        wait.until(
                ExpectedConditions.elementToBeClickable(firstJob)
        ).click();

        return new JobDetailsPage(driver);
    }
}