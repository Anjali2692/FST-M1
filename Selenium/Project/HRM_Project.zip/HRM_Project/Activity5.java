```java
package com.orangehrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyInfoPage {

    private WebDriver driver;

    private By myInfoMenu =
            By.xpath("//a[contains(text(),'My Info')]");

    private By editButton =
            By.xpath("//button[contains(text(),'Edit')]");

    private By firstName =
            By.name("firstName");

    private By lastName =
            By.name("lastName");

    private By saveButton =
            By.xpath("//button[contains(text(),'Save')]");

    public MyInfoPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openMyInfo() {

        driver.findElement(myInfoMenu).click();
    }

    public void editInformation(
            String firstNameValue,
            String lastNameValue) {

        driver.findElement(editButton).click();

        driver.findElement(firstName)
                .clear();

        driver.findElement(firstName)
                .sendKeys(firstNameValue);

        driver.findElement(lastName)
                .clear();

        driver.findElement(lastName)
                .sendKeys(lastNameValue);

        driver.findElement(saveButton).click();
    }
}
```
