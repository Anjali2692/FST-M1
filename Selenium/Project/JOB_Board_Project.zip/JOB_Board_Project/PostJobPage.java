package com.alchemy.jobs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class PostJobPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public PostJobPage(WebDriver driver) {

        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    private By jobTitle =
            By.id("job_title");

    private By location =
            By.id("job_location");

    private By description =
            By.id("job_description");

    private By companyName =
            By.id("company_name");

    private By companyWebsite =
            By.id("company_website");

    private By companyEmail =
            By.id("company_email");

    private By previewButton =
            By.cssSelector("input[value='Preview']");

    private By submitButton =
            By.cssSelector("input[value='Submit Listing']");


    public void enterJobDetails(
            String title,
            String jobLocation,
            String jobDescription,
            String company,
            String website,
            String email) {

        wait.until(
                ExpectedConditions.visibilityOfElementLocated(jobTitle)
        ).sendKeys(title);

        driver.findElement(location).sendKeys(jobLocation);

        driver.findElement(description).sendKeys(jobDescription);

        driver.findElement(companyName).sendKeys(company);

        driver.findElement(companyWebsite).sendKeys(website);

        driver.findElement(companyEmail).sendKeys(email);
    }


    public void clickPreview() {

        driver.findElement(previewButton).click();
    }


    public void submitListing() {

        wait.until(
                ExpectedConditions.elementToBeClickable(submitButton)
        ).click();
    }
}