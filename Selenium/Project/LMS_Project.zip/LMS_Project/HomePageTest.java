```java
package com.alchemy.lms.tests;

import com.alchemy.lms.base.BaseTest;
import com.alchemy.lms.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HomePageTest extends BaseTest {

    @Test
    public void verifyWebsiteTitle() {

        HomePage homePage =
                new HomePage(driver);

        String actualTitle =
                homePage.getPageTitle();

        System.out.println(
                "Website Title: " + actualTitle
        );

        Assert.assertEquals(
                actualTitle,
                "Alchemy LMS – An LMS Application",
                "Website title is incorrect"
        );
    }

    @Test
    public void verifyWebsiteHeading() {

        HomePage homePage =
                new HomePage(driver);

        String actualHeading =
                homePage.getMainHeading();

        System.out.println(
                "Website Heading: " + actualHeading
        );

        Assert.assertEquals(
                actualHeading,
                "Learn from Industry Experts",
                "Website heading is incorrect"
        );
    }

    @Test
    public void verifyFirstInfoBox() {

        HomePage homePage =
                new HomePage(driver);

        String actualTitle =
                homePage.getFirstInfoBoxTitle();

        System.out.println(
                "First Info Box: " + actualTitle
        );

        Assert.assertEquals(
                actualTitle,
                "Actionable Training",
                "First info box title is incorrect"
        );
    }

    @Test
    public void verifySecondPopularCourse() {

        HomePage homePage =
                new HomePage(driver);

        String actualCourse =
                homePage.getSecondPopularCourseTitle();

        System.out.println(
                "Second Popular Course: " + actualCourse
        );

        Assert.assertEquals(
                actualCourse,
                "Email Marketing Strategies",
                "Second popular course is incorrect"
        );
    }
}
