@Test
public void verifySecondHeading() {

    HomePage homePage = new HomePage(driver);

    String actualHeading = homePage.getSecondHeading();

    System.out.println("Second Heading: " + actualHeading);

    Assert.assertEquals(
            actualHeading,
            "Quia quis non"
    );
}