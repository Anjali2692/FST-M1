```java
package com.alchemy.lms.tests;

import com.alchemy.lms.base.BaseTest;
import com.alchemy.lms.pages.ContactPage;
import com.alchemy.lms.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ContactTest extends BaseTest {

    @Test
    public void contactAdmin() {

        HomePage homePage =
                new HomePage(driver);

        homePage.clickContact();

        ContactPage contactPage =
                new ContactPage(driver);

        contactPage.fillContactForm();

        contactPage.submitForm();

        String message =
                contactPage.getSubmissionMessage();

        System.out.println(
                "Contact Form Response: " + message
        );

        Assert.assertFalse(
                message.isEmpty(),
                "No response message displayed"
        );
    }
}
```
