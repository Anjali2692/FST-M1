package com.alchemy.jobs.tests;

import com.alchemy.jobs.base.BaseTest;
import com.alchemy.jobs.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HomePageTests extends BaseTest {

    @Test
    public void verifyWebsiteTitle() {

        HomePage homePage = new HomePage(driver);

        String actualTitle = homePage.getPageTitle();

        System.out.println("Page Title: " + actualTitle);

        Assert.assertEquals(
                actualTitle,
                "Alchemy Jobs – Job Board Application"
        );
    }
}