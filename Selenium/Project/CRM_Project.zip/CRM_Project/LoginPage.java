package com.alchemy.crm.pages;

import com.alchemy.crm.utils.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {

    private WebDriver driver;

    private WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    private By username =
            By.id("user_name");

    private By password =
            By.id("username_password");

    private By loginButton =
            By.id("bigbutton");

    public void login() {

        wait.until(ExpectedConditions.visibilityOfElementLocated(username))
                .sendKeys(ConfigReader.getProperty("username"));

        driver.findElement(password)
                .sendKeys(ConfigReader.getProperty("password"));

        driver.findElement(loginButton)
                .click();
    }

    public boolean isLoginPageDisplayed() {

        return driver.findElement(username).isDisplayed();
    }
}