```java
package com.alchemy.lms.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class HomePage {

    private WebDriver driver;

    /*
     * Navigation
     */
    private By myAccount =
            By.xpath("//a[normalize-space()='My Account']");

    private By allCourses =
            By.xpath("//a[normalize-space()='All Courses']");

    private By contact =
            By.xpath("//a[normalize-space()='Contact']");

    /*
     * Home page heading
     */
    private By mainHeading =
            By.xpath("//*[normalize-space()='Learn from Industry Experts']");

    /*
     * First information box
     */
    private By firstInfoBox =
            By.xpath(
                    "//*[normalize-space()='Actionable Training']"
            );

    /*
     * Popular courses
     *
     * We first locate course titles and then get
     * the second course.
     */
    private By popularCourseTitles =
            By.cssSelector(
                    ".course-item .entry-title, " +
                    ".course-item h3, " +
                    ".course-item h2"
            );

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getPageTitle() {

        return driver.getTitle();
    }

    public String getMainHeading() {

        return driver.findElement(mainHeading)
                .getText()
                .trim();
    }

    public String getFirstInfoBoxTitle() {

        return driver.findElement(firstInfoBox)
                .getText()
                .trim();
    }

    public String getSecondPopularCourseTitle() {

        List<WebElement> courses =
                driver.findElements(popularCourseTitles);

        if (courses.size() < 2) {

            throw new RuntimeException(
                    "Less than two popular courses found."
            );
        }

        return courses.get(1)
                .getText()
                .trim();
    }

    public void clickMyAccount() {

        driver.findElement(myAccount).click();
    }

    public void clickAllCourses() {

        driver.findElement(allCourses).click();
    }

    public void clickContact() {

        driver.findElement(contact).click();
    }
}
```
