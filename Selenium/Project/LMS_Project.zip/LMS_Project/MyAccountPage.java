```java
package com.alchemy.lms.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyAccountPage {

    private WebDriver driver;

    private By loginButton =
            By.xpath(
                    "//a[normalize-space()='Login']"
            );

    public MyAccountPage(WebDriver driver) {
        this.driver = driver;
    }

    public String getPageTitle() {

        return driver.getTitle();
    }

    public void clickLogin() {

        driver.findElement(loginButton).click();
    }
}
```
