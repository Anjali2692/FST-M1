package com.alchemy.jobs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class JobDetailsPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public JobDetailsPage(WebDriver driver) {

        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    private By applyButton =
            By.cssSelector(".application_button");

    private By applicationEmail =
            By.cssSelector(".application_details a");

    public String getApplicationEmail() {

        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(applicationEmail)
        ).getText();
    }

    public void clickApply() {

        wait.until(
                ExpectedConditions.elementToBeClickable(applyButton)
        ).click();
    }
}