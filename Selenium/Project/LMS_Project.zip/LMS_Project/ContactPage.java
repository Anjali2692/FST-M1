```java
package com.alchemy.lms.pages;

import com.alchemy.lms.utils.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ContactPage {

    private WebDriver driver;

    private By fullName =
            By.name("your-name");

    private By email =
            By.name("your-email");

    private By message =
            By.name("your-message");

    private By submit =
            By.cssSelector(
                    "input[type='submit'], button[type='submit']"
            );

    public ContactPage(WebDriver driver) {
        this.driver = driver;
    }

    public void fillContactForm() {

        driver.findElement(fullName)
                .sendKeys(
                        ConfigReader.get("fullName")
                );

        driver.findElement(email)
                .sendKeys(
                        ConfigReader.get("email")
                );

        driver.findElement(message)
                .sendKeys(
                        ConfigReader.get("message")
                );
    }

    public void submitForm() {

        driver.findElement(submit).click();
    }

    public String getSubmissionMessage() {

        return driver.findElement(
                By.cssSelector(
                        ".wpcf7-response-output"
                )
        ).getText();
    }
}
```
