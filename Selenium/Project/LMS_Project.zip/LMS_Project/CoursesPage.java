```java
package com.alchemy.lms.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class CoursesPage {

    private WebDriver driver;

    private By courseCards =
            By.cssSelector(
                    ".course-item"
            );

    public CoursesPage(WebDriver driver) {
        this.driver = driver;
    }

    public int getCourseCount() {

        List<WebElement> courses =
                driver.findElements(courseCards);

        return courses.size();
    }

    public void openFirstCourse() {

        List<WebElement> courses =
                driver.findElements(courseCards);

        if (courses.isEmpty()) {

            throw new RuntimeException(
                    "No courses found"
            );
        }

        courses.get(0).click();
    }
}
