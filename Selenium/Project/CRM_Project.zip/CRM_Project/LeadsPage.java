package com.alchemy.crm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class LeadsPage {

    private WebDriver driver;

    private WebDriverWait wait;

    public LeadsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    private By salesMenu =
            By.xpath("//a[contains(normalize-space(),'Sales')]");

    private By leadsMenu =
            By.xpath("//a[contains(normalize-space(),'Leads')]");

    private By leadTable =
            By.xpath("//table[contains(@class,'list') or contains(@class,'list-view')]");

    public void navigateToLeads() {

        wait.until(
                ExpectedConditions.elementToBeClickable(salesMenu)
        ).click();

        wait.until(
                ExpectedConditions.elementToBeClickable(leadsMenu)
        ).click();
    }

    public void printFirstTenNamesAndUsers() {

        WebElement table =
                wait.until(ExpectedConditions.visibilityOfElementLocated(leadTable));

        List<WebElement> rows =
                table.findElements(By.xpath(".//tbody/tr"));

        int count = 0;

        for (WebElement row : rows) {

            List<WebElement> cells =
                    row.findElements(By.xpath("./td"));

            if (cells.size() >= 2) {

                String name = cells.get(1).getText();

                String user = cells.get(cells.size() - 1).getText();

                System.out.println(
                        "Name: " + name + " | User: " + user
                );

                count++;

                if (count == 10) {
                    break;
                }
            }
        }
    }

    public void printLeadPhoneNumber() {

        WebElement table =
                wait.until(ExpectedConditions.visibilityOfElementLocated(leadTable));

        List<WebElement> rows =
                table.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {

            WebElement firstRow = rows.get(0);

            List<WebElement> icons =
                    firstRow.findElements(
                            By.xpath(".//a | .//img | .//button")
                    );

            for (WebElement icon : icons) {

                String title = icon.getAttribute("title");

                String alt = icon.getAttribute("alt");

                if ((title != null && title.toLowerCase().contains("additional"))
                        ||
                    (alt != null && alt.toLowerCase().contains("additional"))) {

                    icon.click();

                    break;
                }
            }

            By popupPhone =
                    By.xpath(
                            "//*[contains(@class,'modal')]//*[contains(text(),'Phone')]"
                    );

            try {

                WebElement popup =
                        wait.until(
                                ExpectedConditions.visibilityOfElementLocated(
                                        popupPhone
                                )
                        );

                System.out.println(
                        "Phone Number: " + popup.getText()
                );

            } catch (Exception e) {

                System.out.println(
                        "Unable to locate phone number in popup."
                );
            }
        }
    }
}