@Test
public void searchAndApplyForJob() {

    HomePage homePage = new HomePage(driver);

    JobsPage jobsPage = homePage.clickJobs();

    jobsPage.searchJob("QA");

    int jobCount = jobsPage.getJobCount();

    System.out.println("Number of jobs found: " + jobCount);

    Assert.assertTrue(
            jobCount > 0,
            "No jobs found"
    );

    JobDetailsPage jobDetailsPage =
            jobsPage.openFirstJob();

    String email =
            jobDetailsPage.getApplicationEmail();

    System.out.println(
            "Application Email: " + email
    );

    Assert.assertNotNull(email);

    jobDetailsPage.clickApply();
}