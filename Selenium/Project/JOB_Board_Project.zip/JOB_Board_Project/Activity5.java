package com.alchemy.jobs.tests;

import com.alchemy.jobs.base.BaseTest;
import com.alchemy.jobs.pages.HomePage;
import com.alchemy.jobs.pages.JobsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class JobsTests extends BaseTest {

    @Test
    public void navigateToJobsPage() {

        HomePage homePage = new HomePage(driver);

        JobsPage jobsPage = homePage.clickJobs();

        String title = jobsPage.getPageTitle();

        System.out.println("Jobs Page Title: " + title);

        Assert.assertTrue(
                title.toLowerCase().contains("jobs")
        );
    }
}