```java
package com.orangehrm.pages;

import com.orangehrm.utils.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PIMPage {

    private WebDriver driver;

    private By pimMenu =
            By.xpath("//a[contains(text(),'PIM')]");

    private By addButton =
            By.xpath("//button[contains(text(),'Add')]");

    private By firstName =
            By.name("firstName");

    private By middleName =
            By.name("middleName");

    private By lastName =
            By.name("lastName");

    private By saveButton =
            By.xpath("//button[contains(text(),'Save')]");

    public PIMPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openPIM() {

        driver.findElement(pimMenu).click();
    }

    public void addEmployee() {

        driver.findElement(addButton).click();

        driver.findElement(firstName)
                .sendKeys(ConfigReader.get("employeeFirstName"));

        driver.findElement(middleName)
                .sendKeys(ConfigReader.get("employeeMiddleName"));

        driver.findElement(lastName)
                .sendKeys(ConfigReader.get("employeeLastName"));

        driver.findElement(saveButton).click();
    }
}
```
