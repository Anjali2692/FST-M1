```java
package com.orangehrm.tests;

import com.orangehrm.base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class HeaderImageTest extends BaseTest {

    @Test
    public void getHeaderImageUrl() {

        By headerImage =
                By.cssSelector("img");

        String imageUrl =
                driver.findElement(headerImage)
                       .getAttribute("src");

        System.out.println("Header Image URL: " + imageUrl);
    }
}
```
