package com.alchemy.jobs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

    private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    private By mainHeading =
            By.xpath("//h1[contains(normalize-space(),'Welcome to Alchemy Jobs')]");

    private By secondHeading =
            By.xpath("//h2[normalize-space()='Quia quis non']");

    private By headerImage =
            By.xpath("//img");

    private By jobsMenu =
            By.xpath("//a[normalize-space()='Jobs']");

    private By postJobMenu =
            By.xpath("//a[normalize-space()='Post a Job']");


    public String getPageTitle() {
        return driver.getTitle();
    }


    public String getMainHeading() {
        return driver.findElement(mainHeading).getText();
    }


    public String getSecondHeading() {
        return driver.findElement(secondHeading).getText();
    }


    public String getHeaderImageUrl() {

        WebElement image = driver.findElement(headerImage);

        return image.getAttribute("src");
    }


    public JobsPage clickJobs() {

        driver.findElement(jobsMenu).click();

        return new JobsPage(driver);
    }


    public PostJobPage clickPostJob() {

        driver.findElement(postJobMenu).click();

        return new PostJobPage(driver);
    }
}