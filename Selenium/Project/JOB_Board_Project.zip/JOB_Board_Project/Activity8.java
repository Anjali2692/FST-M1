package com.alchemy.jobs.tests;

import com.alchemy.jobs.pages.LoginPage;
import com.alchemy.jobs.utils.ConfigReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AdminTests {

    private WebDriver driver;

    @BeforeMethod
    public void setUp() {

        io.github.bonigarcia.wdm.WebDriverManager
                .chromedriver()
                .setup();

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.get(
                ConfigReader.get("adminUrl")
        );
    }

    @Test
    public void loginToBackend() {

        LoginPage loginPage =
                new LoginPage(driver);

        loginPage.login(
                ConfigReader.get("username"),
                ConfigReader.get("password")
        );

        Assert.assertTrue(
                loginPage.isLoggedIn(),
                "User was not logged into WordPress admin"
        );

        System.out.println(
                "Successfully logged into backend"
        );
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}