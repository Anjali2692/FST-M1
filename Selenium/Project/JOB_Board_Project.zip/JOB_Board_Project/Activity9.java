package com.alchemy.jobs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AdminJobPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public AdminJobPage(WebDriver driver) {

        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    private By jobListingsMenu =
            By.xpath("//div[contains(@class,'wp-menu-name') and normalize-space()='Job Listings']");

    private By addNew =
            By.xpath("//a[normalize-space()='Add New']");

    private By jobTitle =
            By.id("post-title-0");

    private By publishButton =
            By.id("publish");


    public void clickJobListings() {

        wait.until(
                ExpectedConditions.elementToBeClickable(jobListingsMenu)
        ).click();
    }


    public void clickAddNew() {

        wait.until(
                ExpectedConditions.elementToBeClickable(addNew)
        ).click();
    }


    public void enterJobTitle(String title) {

        wait.until(
                ExpectedConditions.visibilityOfElementLocated(jobTitle)
        ).sendKeys(title);
    }


    public void publish() {

        wait.until(
                ExpectedConditions.elementToBeClickable(publishButton)
        ).click();
    }
}